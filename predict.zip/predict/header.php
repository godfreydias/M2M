<!doctype html>
<html>
    <head>

        <title>Smart Meter Reading</title>

        <link href='https://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" href="public/css/font-awesome/css/font-awesome.min.css">
        <link href="public/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="public/js/jquery-ui/jquery-ui.min.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" type="text/css" href="public/js/formValidation/formValidation.min.css" />
        <link rel="stylesheet" type="text/css" href="public/css/pixicon.css" />
        <link rel="stylesheet" type="text/css" href="public/css/app.css" />
        <link rel="shortcut icon" href="public/images/favicon.ico">


<!-- Facebook Pixel Code -->

<!-- End Facebook Pixel Code -->

    </head>
    <body>
        <div class="main-body">



            <div id="main-content">
