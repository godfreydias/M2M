<?php

/**
 * Description of functions
 *
 * @author sms
 */

ini_set('memory_limit', '2048M');

require_once 'db_connect.php';

class functions extends db_connect {

    public function test_input($data)
    {
        $data = trim(strtolower($data));
        $data = strip_tags($data);
        $data = htmlspecialchars($data);
        $data = mysqli_real_escape_string($this->mysqli,$data);
        return $data;
    }
    /* Test_Input Function closed Here */

    public function get_datetime()
    {
        date_default_timezone_set('Asia/Calcutta');
        $date1=date( "Y-m-d h:i:s");
        return $date1;
    }
    public function get_datetime_html()
    {
        date_default_timezone_set('Asia/Calcutta');
        $date1=date( "Y-m-d\TH:i:s");
        return $date1;
    }

    public function data_insert($sql)
    {
        $result= $this->mysqli->query($sql) or die($this->mysqli->error);
		return $result;
    }

	public function data_insert_return_id($sql)
    {

        $result= $this->mysqli->query($sql) or die($this->mysqli->error);
		return $id=$this->mysqli->insert_id;
    }

    public function data_select($sql)
    {
        $select=$this->mysqli->query($sql) or die($this->mysqli->error);
        if($select->num_rows==0)
        {
            return 'no';
        }
        else
        {
            while ($row = $select->fetch_array(MYSQLI_ASSOC))
            {
                $data[]=$row;
            }
            return $data;
        }

    }

    public function data_select_row($sql)
    {
        $select=$this->mysqli->query($sql) or die($this->mysqli->error);
        if($select->num_rows==0)
        {
            return 'no';
        }
        else
        {
            while ($row = mysqli_fetch_row($select))
            {
              foreach($row as $val){
                $data[]=$val;
              }
            }
            return $data;
        }

    }


     public function data_select_ocare_details($sql)
    {

        $select=$this->mysqli->query($sql) or die($this->mysqli->error);
        if($select->num_rows==0)
        {
            return 'no';
        }
        else
        {
            while ($row = $select->fetch_array(MYSQLI_ASSOC))
            {
                $data[]=$row;
            }
            return $data;
        }


    }

    public function data_update($sql)
    {
        $update=  $this->mysqli->query($sql) or die($this->mysqli->error);
        return $update;
    }

	public function data_delete($sql)
    {
        $update=  $this->mysqli->query($sql) or die($this->mysqli->error);
        return $update;
    }
    // Update Function Closed Here
    function mobile_validate($mobile)
    {
        if(preg_match('/^((\+){0,1}91(\s){0,1}(\-){0,1}(\s){0,1})?([0-9]{10})$/', $mobile,$matches))
        {
            return true;
        }
        return false;
    }

    function insert_citrus_response($sql)
    {
        $result= $this->mysqli->query($sql) or die($this->mysqli->error);
        return $result;
    }


    function update_insurance($sql)
    {
$update=  $this->mysqli->query($sql) or die($this->mysqli->error);
        return $update;

    }

     function delete_entry($sql)
    {
$delete=  $this->mysqli->query($sql) or die($this->mysqli->error);
        return $delete;

    }

    public function update_query($column,$value,$update_id)
    {
        $update=  $this->mysqli->query('UPDATE elctricity_reading SET '.$column.' = '.$value.' WHERE `elctricity_reading`.`id` = '.$update_id.';') or die($this->mysqli->error);
        return $update;
    }

      public function update_query_week($column,$value,$update_id)
    {
        $update=  $this->mysqli->query('UPDATE elctricity_week_reading SET '.$column.' = '.$value.' WHERE `elctricity_week_reading`.`id` = '.$update_id.';') or die($this->mysqli->error);
        return $update;
    }

    public function insert_feed($year,$month,$val)
    {
      $insert=  $this->mysqli->query('INSERT INTO `elctricity_reading` (`year`, `quarter`, `electricity`) VALUES ('.$year.', '.$month.', '.$val.');') or die($this->mysqli->error);
      return $insert;
    }

    public function insert_feed_week($year,$month,$week,$val)
    {
      $insert=  $this->mysqli->query('INSERT INTO `elctricity_week_reading` (`year`, `quarter`,`week`, `electricity`) VALUES ('.$year.', '.$month.','.$week.' ,'.$val.');') or die($this->mysqli->error);
      return $insert;
    }
}

?>
