    </div>
</div>
<footer id="footer" class="padding-vert-20 clearfix">
    
</footer>



        <script type="text/javascript" src="public/js/jQuery-2.2.0.min.js" ></script>
        <script src="public/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="public/js/jquery-ui/jquery-ui.min.js" type="text/javascript"></script>
        <!-- <script src="public/js/perfect-scrollbar/min/perfect-scrollbar-0.4.6.with-mousewheel.min.js" type="text/javascript"></script> -->
        <!-- <script src="public/js/Magnific-Popup/dist/jquery.magnific-popup.min.js" type="text/javascript"></script> -->
        <!-- <script src="public/js/formValidation/formValidation.min.js" type="text/javascript"></script>
        <script src="public/js/formValidation/bootstrap.min.js" type="text/javascript"></script> -->

        <script src="public/js/jquery-validation/dist/jquery.validate.js" type="text/javascript"></script>


        <script src="public/js/moment/min/moment.min.js"></script>
        <script src="public/js/moment/min/moment-with-langs.min.js"></script>
        <script type="text/javascript" src="public/js/app.js" ></script>







    </body>
</html>
