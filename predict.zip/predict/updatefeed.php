<?php

$global_array=array();




$end=false;
while($end==false){
        $end=true;
        $sql = "SELECT * FROM `elctricity_reading` order by year desc, quarter desc limit 1";

        $data = $con->data_select($sql);

        if($data[0]['quarter']==12){
          $year=$data[0]['year'];
          $year++;
          $month='1';
        }
        else{
            $year=$data[0]['year'];
            $month=$data[0]['quarter'];
            $month++;
        }


        $sql = "SELECT electricty FROM feed_values WHERE MONTH(created_at) = ".$month." AND YEAR(created_at) = ".$year;
        $data_avg = $con->data_select_row($sql);
          if($data_avg!='no'){
            $average_val = array_sum($data_avg) / count($data_avg);
            //print_r($average_val); die;


            $return_val=$con->insert_feed($year,$month,$average_val);
            $end=false;
          }
          

        $up_date='1';
        $down_date='8';
          $sql = "SELECT electricty FROM feed_values WHERE MONTH(created_at) = ".$month." AND YEAR(created_at) = ".$year." AND (DAY(created_at) BETWEEN  ".$up_date." AND ".$down_date." )";
        //print_r($sql); die;

        $data_avg = $con->data_select_row($sql);
          if($data_avg!='no'){
            $average_val = array_sum($data_avg) / count($data_avg);
            //print_r($average_val); die;


            $return_val=$con->insert_feed_week($year,$month,'1',$average_val);
            $end=false;

          }

          $up_date='9';
        $down_date='16';
          $sql = "SELECT electricty FROM feed_values WHERE MONTH(created_at) = ".$month." AND YEAR(created_at) = ".$year." AND (DAY(created_at) BETWEEN  ".$up_date." AND ".$down_date." )";
        //print_r($sql); die;

        $data_avg = $con->data_select_row($sql);
          if($data_avg!='no'){
            $average_val = array_sum($data_avg) / count($data_avg);
            //print_r($average_val); die;


            $return_val=$con->insert_feed_week($year,$month,'2',$average_val);
            $end=false;

          }

          $up_date='17';
        $down_date='24';
          $sql = "SELECT electricty FROM feed_values WHERE MONTH(created_at) = ".$month." AND YEAR(created_at) = ".$year." AND (DAY(created_at) BETWEEN  ".$up_date." AND ".$down_date." )";
        //print_r($sql); die;

        $data_avg = $con->data_select_row($sql);
          if($data_avg!='no'){
            $average_val = array_sum($data_avg) / count($data_avg);
            //print_r($average_val); die;


            $return_val=$con->insert_feed_week($year,$month,'3',$average_val);
            $end=false;

          }

          $up_date='25';
        $down_date='31';
          $sql = "SELECT electricty FROM feed_values WHERE MONTH(created_at) = ".$month." AND YEAR(created_at) = ".$year." AND (DAY(created_at) BETWEEN  ".$up_date." AND ".$down_date." )";
        //print_r($sql); die;

        $data_avg = $con->data_select_row($sql);
          if($data_avg!='no'){
            $average_val = array_sum($data_avg) / count($data_avg);
            //print_r($average_val); die;


            $return_val=$con->insert_feed_week($year,$month,'4',$average_val);
            $end=false;

          }



    }      
//print_r($global_array); die;
 // $var=getSmoothVal(1,$global_array[1]['electricity'],$global_array[0]['electricity'],$global_array[0]['trend']);
 //
 // echo $var;



?>
