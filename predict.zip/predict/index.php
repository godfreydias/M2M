<?php
include('header.php') ?>




    <section id="features-tab">
        <div class="container">
            <div class=" clearfix md-display-flex">

                <div class="tab-content sm-width-auto">
                    <div class="tab-pane active" id="features">
                    <h2 class="sp padding-bottom-10 padding-left-10">Calculate Next month's predicted bill?</h2>

                        <ul>

                          <li>
                            <form action="getindex.php">
                              <input type="button" id="month_btn" value="Click" class="btn btn-primary calc"/>
                            </form>
                          </li>


                       </ul>
                  </div>

                </div>

                <div class="tab-content sm-width-auto">
                    <div class="tab-pane active" id="features">
                    <h2 class="sp padding-bottom-10 padding-left-10">Calculate Next week's predicted bill?</h2>

                        <ul>

                          <li>
                            <form action="getweekindex.php">
                              <input type="button" id="month_week" value="Click" class="btn btn-primary calc"/>
                            </form>
                          </li>


                       </ul>
                  </div>

                </div>

            </div>
			  <div class="jumbotron hide " style="margin-top: 50px;">
				<h2 class="response">Next Month's predicted bill is Rs <strong>525.84</strong> </h2> 
				
			</div>
        </div>
		
    </section>

<?php include('footer.php'); ?>
<script>
 $(".calc").click(function () {
        
        
            var btn = $(this).find("button[type=submit]:focus").val();
            var cid = $(this).parent().find(".cid").val();
            var action = $(this).closest('form').attr("action");
            $.ajax({
                    type: 'post',
                    url: action,
                    success: function (res) {
                        console.log(res);
                        $('.jumbotron').removeClass('hide');
                        $('.response').html(res);
                    }
                });
         
    });</script>