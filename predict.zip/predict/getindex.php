<?php
session_start();

//include('header.php');
include('functions.php');
$global_array=array();

function getSmoothVal($i,$elec_current,$elec_prev,$trend_prev)
{
//  echo $elec_current; die;
  $st=(0.5*$elec_current)+((1-0.5)*($elec_prev+$trend_prev));

  return $st;
}

function getTrendVal($i,$smooth_current,$smooth_prev,$trend_prev)
{
//  echo $elec_current; die;
  $tt=0.5*($smooth_current-$smooth_prev)+((1-0.5)*($trend_prev));

  return $tt;
}

function getCycleVal($i,$elec_current,$smooth_current,$cycle_prev_quarter)
{
//  echo $elec_current; die;
  $ct=0.5*($elec_current-$smooth_current)+((1-0.5)*($cycle_prev_quarter));

  return $ct;
}

function predictVal($i,$smooth_prev,$trend_prev,$cycle_prev_quarter)
{
//  echo $elec_current; die;
  $pv=$smooth_prev+$trend_prev+$cycle_prev_quarter;

  return $pv;
}


$con =new functions();

include('updatefeed.php');

$sql = "SELECT * FROM `elctricity_reading`";

$data = $con->data_select($sql);
$global_array=$data;
//print_r($data); die;
$i=0;
foreach ($data as $row){

  if(empty($row['smooth'] && $row['smooth']!='0' )){
    $var=getSmoothVal($i,$global_array[$i]['electricity'],$global_array[$i-1]['electricity'],$global_array[$i-1]['trend']);

    $global_array[$i]['smooth']=$var;
    $con->update_query('smooth',$var,$row['id']);

    //print_r($global_array); die;
  }

  if(empty($row['trend']) && $row['trend']!='0'){
    $var=getTrendVal($i,$global_array[$i]['smooth'],$global_array[$i-1]['smooth'],$global_array[$i-1]['trend']);

    $global_array[$i]['trend']=$var;
    $con->update_query('trend',$var,$row['id']);


  }

  if(empty($row['cyclic']) && $row['cyclic']!='0'){
    $var=getCycleVal($i,$global_array[$i]['electricity'],$global_array[$i]['smooth'],$global_array[$i-12]['cyclic']);

    $global_array[$i]['cyclic']=$var;
    $con->update_query('cyclic',$var,$row['id']);
    //print_r($global_array); die;
  }
  if($i>=12){
    if(empty($row['predicted']) && $row['predicted']!='0'){
      $var=predictVal($i,$global_array[$i-1]['smooth'],$global_array[$i-1]['trend'],$global_array[$i-12]['cyclic']);

      $global_array[$i]['predicted']=$var;
      $con->update_query('predicted',$var,$row['id']);

    }

  }
//  print_r($global_array); die;

  $i++;
}

$var=predictVal($i,$global_array[$i-1]['smooth'],$global_array[$i-1]['trend'],$global_array[$i-12]['cyclic']);
//print_r($global_array);
    $var=$var*9.9999;
    $var=number_format((float)$var, 2, '.', '');
echo 'Predicted value for next month is Rs <strong>'.$var.'</strong>';
//print_r($global_array); die;
 // $var=getSmoothVal(1,$global_array[1]['electricity'],$global_array[0]['electricity'],$global_array[0]['trend']);
 //
 // echo $var;



?>
