$(document).ready(function() {

    $('.first-text-input').focus();

    $('#banner-carousel').carousel();

        $('#city').on('change',function(){
    	var city_id = $('#city').val();
    	$.ajax({
            type: 'post',
            url: 'ajax.php',
            //dataType: "json",
            data: {'city_id':city_id,'action':'collection_centres_list'},
            success: function(res){
            	console.log(res);
                $('#collection_centres').html(res);
            }
        });
    });
    $('#event_city').on('change',function(){
        var city_id = $('#event_city').val();
        if(city_id == 93)
        {
            $('.event_date').html('13th and 14th August').css('color','#fb5044');
        }
        else
        {
            $('.event_date').html('6th and 7th August').css('color','#fb5044');
        }
        $.ajax({
            type: 'post',
            url: 'ajax.php',
            //dataType: "json",
            data: {'city_id':city_id,'action':'event_centres_list'},
            success: function(res){
                console.log(res);
                $('#collection_centres').html(res);
            }
        });
    });

    /*$('#online-registration-form').formValidation({
        framework: 'bootstrap',
        //defaultSubmit: true,
        icon: {
            valid: 'fa fa-check',
            invalid: 'fa fa-times',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            first_name: {
                validators: {
                    notEmpty: {
                        message: 'Please enter first name'
                    }
                }
            },
            jio_id: {
                validators: {
                    stringLength: {
                        max: 16,
                        min: 16,
                        message: 'JIO ID should have exactly 16 digits'
                    },
                    integer: {
                        message: 'JIO ID should be a number'
                    }
                }
            },
            minor_jio_id: {
                validators: {
                    stringLength: {
                        max: 16,
                        min: 16,
                        message: 'JIO ID should have exactly 16 digits'
                    }
                }
            },
            pincode: {
                validators: {
                    stringLength: {
                        min: 6,
                        max: 6,
                        message: 'Please enter valid pincode',
                    },
                    integer: {
                        message: 'Pincode should be a number',
                    }
                }
            },
            dob: {
                validators: {
                    date: {
                        format: 'MM/DD/YYYY',
                        message: 'The date of birth is invalid'
                    },
                    notEmpty: {
                        message: 'Please enter date of birth'
                    },
                }
            },
            age: {
                validators: {
                    integer: {
                        message: 'Age is not valid',
                    },
                    notEmpty: {
                        message: 'Date of birth not specified'
                    },
                }
            },
            mobile: {
                validators: {
                    integer: {
                        message: 'Mobile number is not valid',
                    },
                    notEmpty: {
                        message: 'Please enter mobile number'
                    },
                    stringLength: {
                        min: 10,
                        max: 10,
                        message: 'Mobile number must have 10 digits',
                    },
                }
            },
            pincode: {
                validators: {
                    integer: {
                        message: 'Pincode is not valid',
                    },
                    notEmpty: {
                        message: 'Please enter pincode'
                    },
                    stringLength: {
                        min: 6,
                        max: 6,
                        message: 'Pincode must have 6 digits',
                    },
                }
            },
            residence_no: {
                validators: {
                    integer: {
                        message: 'Residence phone no. is not valid',
                    },
                    stringLength: {
                        min: 8,
                        max: 10,
                        message: 'Residence phone no. must have either 8 or 10 digits',
                    },
                }
            },
            email: {
                validators: {
                    emailAddress: {
                        message: 'The email address is not valid'
                    },
                    notEmpty: {
                        message: 'Please enter email id'
                    },
                }
            },
            term_agreement: {
                validators: {
                    notEmpty: {
                        message: 'Please agree to terms and conditions'
                    },
                }
            },
        }
    });*/

    $('#online-registration-form').validate({
        ignore: [],
        rules: {
            first_name: {
                required: true
            },
            last_name: {
                required: true
            },
            jio_id: {
                required: false,
                digits: true,
                minlength: 16,
                maxlength: 16,
            },
            pincode: {
                required: true,
                digits: true,
                minlength: 6,
                maxlength: 6,
            },
            mobile: {
                required: true,
                digits: true,
                minlength: 10,
                maxlength: 10,
            },
            residence_no: {
                required: true,
                digits: true,
                minlength: 11,
                maxlength: 15,
            },
            email: {
                required: true,
                email: true,
            },
            address: {
                required: true,
            },
            term_agreement: {
                required: true,
            },
            state: {
                required: true,
            },
            city: {
                required: {
                    depends: function() {
                        return !$('input[name="is_other_city"]').prop('checked');
                    }
                },
            },
            other_city: {
                required: {
                    depends: function() {
                        return $('input[name="is_other_city"]').prop('checked');
                    }
                },
            },
            residence_no: {
                required: false,
            }
        },
        messages: {
        },
    });

    /*$('#online-registration-form').validate({
        rules: {
            first_name: "required",
            email: { email: true, required: true },
            jio_id: { required: true, min: { param: 16 }, max: { param: 16 } },
        }
    });*/

    $('.dob').datepicker({
        changeMonth: true,
        changeYear: true,
        maxDate: new Date(),
        yearRange: '-100:+0',
        defaultDate: "-1Y",
    });

     /*$('#online-registration-form input[type="submit"]').click(function(e) {
        if ( $('#online-registration-form').data('formValidation').isValid() ) {
            $('#online-registration-form').data('formValidation').defaultSubmit();
        }
    });*/

    $(document).on('change', 'input[name="dob"]', function(e) {
        var age = Math.floor(moment(new Date()).diff(moment($( this ).datepicker( "getDate" )),'years',true));
        $('input[name="age"]').val(age);

        if ( age < 18 )
            $('.minor-wrapper').show();
        else
            $('.minor-wrapper').hide();
    });

    $(document).on('change', 'select[name="state"]', function(e) {
        var val = $(this).val();
        //$('select[name="city"] option:not(.default)').hide();

        if ( val == '' ) {
            $('select[name="city"]').val('').attr('disabled', 'disabled');
        } else {
            $.ajax({
                url: 'cities-by-state.php',
                data: { state_id: val },
                success: function(response) {
                    $('select[name="city"]').html(response);

                    if ( $('input[name="is_other_city"]').prop('checked') )
                        $('select[name="city"]').attr('disabled', 'disabled');
                    else
                        $('select[name="city"]').removeAttr('disabled');
                },
                error: function(response) {

                }
            });
        }
        /*if ( val == '' ) {
            $('select[name="city"]').val('').attr('disabled', 'disabled');
        } else {
            $('select[name="city"]').removeAttr('disabled').find('option[data-state="'+ val +'"]').show();
        }*/
    });

    $(document).on('change', 'input[name="is_other_city"]', function(e) {
        if ( $(this).prop('checked') ) {
            $('#other-city-wrapper').removeClass('hide');
            $('input[name="other_city"]').focus();
            $('select[name="city"]').attr('disabled', 'disabled');
        } else {
            $('#other-city-wrapper').addClass('hide');
            $('small[data-fv-for="other_city"]').hide();
            $('select[name="city"]').removeAttr('disabled');
        }
    });

    $(document).on('change', 'input[name="terms_agreement"]', function(e) {
        var form = $(this).closest('form');

        if ( $(this).prop('checked') )
            form.find('input[type="submit"]').removeAttr('disabled');
        else
            form.find('input[type="submit"]').attr('disabled', 'disabled');
    });
});