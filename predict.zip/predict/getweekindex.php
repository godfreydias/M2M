<?php
session_start();

//include('header.php');
include('functions.php');
$global_array=array();

function getSmoothVal($i,$elec_current,$elec_prev,$trend_prev)
{
//  echo $elec_current; die;
  $st=(0.5*$elec_current)+((1-0.5)*($elec_prev+$trend_prev));

  return $st;
}

function getTrendVal($i,$smooth_current,$smooth_prev,$trend_prev)
{
//  echo $elec_current; die;
  $tt=0.5*($smooth_current-$smooth_prev)+((1-0.5)*($trend_prev));

  return $tt;
}

function getCycleVal($i,$elec_current,$smooth_current,$cycle_prev_quarter)
{
//  echo $elec_current; die;
  $ct=0.5*($elec_current-$smooth_current)+((1-0.5)*($cycle_prev_quarter));

  return $ct;
}

function predictVal($i,$smooth_prev,$trend_prev,$cycle_prev_quarter)
{
//  echo $elec_current; die;
  $pv=$smooth_prev+$trend_prev+$cycle_prev_quarter;

  return $pv;
}


$con =new functions();

include('updatefeed.php');

$sql = "SELECT * FROM `elctricity_week_reading`";

$data = $con->data_select($sql);

if(count($data)>=8){
    $data[0]['smooth']=$data[0]['electricity'];
    for($k=0;$k<=7;$k++){
      $data[$k]['cyclic']='0';
    }
    $global_array=$data;
    //print_r($data); 
    $i=0;
    foreach ($data as $row){
 
      if(empty($row['smooth'] && $row['smooth']!='0' )){
        $var=getSmoothVal($i,$global_array[$i]['electricity'],$global_array[$i-1]['electricity'],$global_array[$i-1]['trend']);

        $global_array[$i]['smooth']=$var;
        $con->update_query_week('smooth',$var,$row['id']);

        //print_r($global_array); die;
      }

      if(empty($row['trend']) && $row['trend']!='0'){
        $var=getTrendVal($i,$global_array[$i]['smooth'],$global_array[$i-1]['smooth'],$global_array[$i-1]['trend']);

        $global_array[$i]['trend']=$var;
        $con->update_query_week('trend',$var,$row['id']);


      }

      if(empty($row['cyclic']) && $row['cyclic']!='0'){
        $var=getCycleVal($i,$global_array[$i]['electricity'],$global_array[$i]['smooth'],$global_array[$i-8]['cyclic']);

        $global_array[$i]['cyclic']=$var;
        $con->update_query_week('cyclic',$var,$row['id']);
        //print_r($global_array); die;
      }
      if($i>=8){
        if(empty($row['predicted']) && $row['predicted']!='0'){
          $var=predictVal($i,$global_array[$i-1]['smooth'],$global_array[$i-1]['trend'],$global_array[$i-8]['cyclic']);

          $global_array[$i]['predicted']=$var;
          $con->update_query_week('predicted',$var,$row['id']);

        }

      }
      //print_r($global_array); die;

      $i++;
    }

    $var=predictVal($i,$global_array[$i-1]['smooth'],$global_array[$i-1]['trend'],$global_array[$i-8]['cyclic']);
    $var=$var*9.99;
    $var=number_format((float)$var, 2, '.', '');
    echo 'Predicted value for next week is Rs <strong>'.$var.'</strong>';
   

}
else{
  echo 'You need to complete atleast 8 weeks of use of the machine';
}

?>
